import '../css/styles.css'
import Cart from './cart'
import PizzaCard from './pizzaCard'
import {Link} from "react-router-dom"
let Content=()=>{
    return(
        <div className="container">
  <h1>Menu</h1>
  <hr />
  <div className="row">
    <div className="col-12 col-md-12 col-lg-7 col-xl-7 col-xxl-7">
      
    
      {/* <hr id="bs"></hr> */}
      <div className='row'>
      <h2 class='category'><span>Best Sellers</span></h2>      
        <PizzaCard title="Best Sellers"/>
       <p/><p/><p/>

       <h2 class='category'><span>Veg Pizzas</span></h2>      
        <PizzaCard title="Veg Pizzas"/>
        <p/><p/><p/>

       <h2 class='category'><span>Non Veg Pizzas</span></h2>      
        <PizzaCard title="Non Veg Pizzas"/>
       <p/><p/><p/>

       <h2 class='category'><span>Side Dishes</span></h2>      
        <PizzaCard title="Side Dishes"/>
        <p/><p/><p/>

       <h2 class='category'><span>Desserts</span></h2>      
        <PizzaCard title="Desserts"/>
       </div>
       <br />

    </div>
    <div className="col-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5">
     <Cart/>
     <br />
    </div>
   
    {/* <button id='fixedbutton'>GO TO CART</button> */}

    <Link to="/cart" className='fixedbutton'>
    GO TO CART
          </Link>
  </div>
</div>
    )
}
export default Content