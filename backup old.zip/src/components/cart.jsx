import '../css/styles.css'
import {Link} from "react-router-dom"
let Cart=()=>{
    return(
        <div id='cart'>
        <div style={{display:'flex',justifyContent:'space-between'}}>
          <h2>Cart</h2>
          <button className='btn btn-danger'>Clear Cart</button>
        </div>
        <hr />
        <Link to="/cart" id='gotocart'>
    GO TO CART
          </Link>
        {/* <button id='gotocart'>GO TO CART</button> */}
      </div>
    )
}
export default Cart