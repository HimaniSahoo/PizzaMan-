import MyImage from '../images/pizzaman.png';
import '../css/styles.css'
let Top=()=>{
    return(
        <nav style={{ height:"56px" }} className="navbar navbar-expand-lg bg-light">
            <div className="container-fluid">
            <a href="#" className="container">
            <img alt="Logo" width="80" height="56"  src={MyImage}/>
            </a>   
            </div>
        </nav>
    )
}
export default Top