import data from "../data.json"
let PizzaCard=(props)=>{
    return(
        <>
            {data.map((val,idx)=>{
            if(val.name===props.title)
            return val.items.map((val,idx)=>{
              return<div className="col-12 col-md-12 col-lg-5 col-xl-4 col-xxl-4" key={idx}>
                <div className='pizzaCard'>
                  <div>
               <img className='images' style={{borderTopRightRadius:'10px',borderTopLeftRadius:'10px'}} height={90} width={200} key={idx} src={val.img}/>
               </div>
               <div style={{padding:'10px'}}>
                <p>{val.name}</p>
               <p style={{fontSize:'10px' , marginTop:'-15px'}}><i>{val.desc}</i></p>
               <div style={{display:'flex',justifyContent:'space-between', height:'20px', lineHeight:'0.1em'}}>
                <p>₹ {val.price}</p>
                <div style={{display:'flex'}}>
                <button style={{height:'20px',width:'20px', lineHeight:'0.1em', paddingRight:'5px'}}>-</button>
                <p> &nbsp; 1 &nbsp;</p>
                <button>+</button>
                </div>
                </div>
               </div>
               </div>
               </div>
               
            })
          })
      }
      </>
    )
}
export default PizzaCard