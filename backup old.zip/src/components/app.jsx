import Content from "./content"
import Footer from "./footer"
import Top from "./header"
import '../css/styles.css'
import {BrowserRouter,Routes,Route,NavLink,Switch} from "react-router-dom"
import CartTotal from "./cartTotal"

let App=()=>{
    return(
            <BrowserRouter>
        <div>
            <Top/>
            <Routes>
            <Route path="/" element={<Content/>}/>

            <Route path="/cart" element={<CartTotal/>}/>

            </Routes>
            <Footer/>
            
        </div>
            </BrowserRouter>
    )
}
export default App