function ErrorHandler() {
    return (
      <div className="container" role="alert" style={{display:"grid",alignContent:"center",justifyContent:"center",height:"600px",width:"600px"}}>
        
        <p>An error occurred please try later</p>
        <img src={"https://media3.giphy.com/media/8L0Pky6C83SzkzU55a/200w.gif?cid=6c09b952va3o5r8r0c7idkak1qh4huej250t8a4ws26s17h3&rid=200w.gif&ct=g"} alt="" />
      </div>
    )
  }
  export default ErrorHandler